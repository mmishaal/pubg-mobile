package com.amazon.kindelx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.os.Process;
import android.util.AttributeSet;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.objectweb.asm.Opcodes;

/* renamed from: com.amazon.kindelx.a */
public class a extends View implements Runnable {
    static long sleepTime;
    int FPS = 60;
    SimpleDateFormat formatter;
    Paint mFilledPaint;
    Paint mStrokePaint;
    Paint mTextPaint;
    Thread mThread;
    Date time;

    private String getWeapon(int i) {
        if (i == 101006) {
            return "AUG";
        }
        if (i == 101008) {
            return "M762";
        }
        if (i == 101003) {
            return "SCAR-L";
        }
        if (i == 101004) {
            return "M416";
        }
        if (i == 101002) {
            return "M16A-4";
        }
        if (i == 101009) {
            return "Mk47 Mutant";
        }
        if (i == 101010) {
            return "G36C";
        }
        if (i == 101007) {
            return "QBZ";
        }
        if (i == 101001) {
            return "AKM";
        }
        if (i == 101005) {
            return "Groza";
        }
        if (i == 102005) {
            return "Bizon";
        }
        if (i == 102004) {
            return "TommyGun";
        }
        if (i == 102007) {
            return "MP5K";
        }
        if (i == 102002) {
            return "UMP";
        }
        if (i == 102003) {
            return "Vector";
        }
        if (i == 102001) {
            return "Uzi";
        }
        if (i == 105002) {
            return "DP28";
        }
        if (i == 105001) {
            return "M249";
        }
        if (i == 103003) {
            return "AWM";
        }
        if (i == 103010) {
            return "QBU";
        }
        if (i == 103009) {
            return "SLR";
        }
        if (i == 103004) {
            return "SKS";
        }
        if (i == 103006) {
            return "Mini14";
        }
        if (i == 103002) {
            return "M24";
        }
        if (i == 103001) {
            return "Kar98k";
        }
        if (i == 103005) {
            return "VSS";
        }
        if (i == 103008) {
            return "Win94";
        }
        if (i == 103007) {
            return "Mk14";
        }
        if (i == 104003) {
            return "S12K";
        }
        if (i == 104004) {
            return "DBS";
        }
        if (i == 104001) {
            return "S686";
        }
        if (i == 104002) {
            return "S1897";
        }
        if (i == 108003) {
            return "Sickle";
        }
        if (i == 108001) {
            return "Machete";
        }
        if (i == 108002) {
            return "Crowbar";
        }
        if (i == 107001) {
            return "CrossBow";
        }
        if (i == 108004) {
            return "Pan";
        }
        if (i == 106006) {
            return "SawedOff";
        }
        if (i == 106003) {
            return "R1895";
        }
        if (i == 106008) {
            return "Vz61";
        }
        if (i == 106001) {
            return "P92";
        }
        if (i == 106004) {
            return "P18C";
        }
        if (i == 106005) {
            return "R45";
        }
        if (i == 106002) {
            return "P1911";
        }
        if (i == 106010) {
            return "DesertEagle";
        }
        return null;
    }

    public static void ChangeFps(int i) {
        sleepTime = (long) (1000 / (i + 20));
    }

    public a(Context context) {
        super(context, (AttributeSet) null, 0);
        InitializePaints();
        setFocusableInTouchMode(false);
        setBackgroundColor(0);
        this.time = new Date();
        this.formatter = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        sleepTime = (long) (1000 / this.FPS);
        this.mThread = new Thread(this);
        this.mThread.start();
    }

    /* access modifiers changed from: protected */
    @SuppressLint("WrongConstant")
    public void onDraw(Canvas canvas) {
        if (canvas != null && getVisibility() == 0) {
            ClearCanvas(canvas);
            e.DrawOn(this, canvas);
        }
    }

    public void run() {
        Process.setThreadPriority(10);
        while (this.mThread.isAlive() && !this.mThread.isInterrupted()) {
            try {
                long currentTimeMillis = System.currentTimeMillis();
                postInvalidate();
                Thread.sleep(Math.max(Math.min(0, sleepTime - (System.currentTimeMillis() - currentTimeMillis)), sleepTime));
            } catch (Exception unused) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    public void InitializePaints() {
        this.mStrokePaint = new Paint();
        this.mStrokePaint.setStyle(Paint.Style.STROKE);
        this.mStrokePaint.setAntiAlias(true);
        this.mStrokePaint.setColor(Color.rgb(0, 0, 0));
        this.mFilledPaint = new Paint();
        this.mFilledPaint.setStyle(Paint.Style.FILL);
        this.mFilledPaint.setAntiAlias(true);
        this.mFilledPaint.setColor(Color.rgb(0, 0, 0));
        this.mTextPaint = new Paint();
        this.mTextPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        this.mTextPaint.setAntiAlias(true);
        this.mTextPaint.setColor(Color.rgb(0, 0, 0));
        this.mTextPaint.setTextAlign(Paint.Align.CENTER);
        this.mTextPaint.setStrokeWidth(1.1f);
    }

    public void ClearCanvas(Canvas canvas) {
        canvas.drawColor(0, PorterDuff.Mode.CLEAR);
    }

    public void DrawLine(Canvas canvas, int i, int i2, int i3, int i4, float f, float f2, float f3, float f4, float f5) {
        this.mStrokePaint.setColor(Color.rgb(i2, i3, i4));
        this.mStrokePaint.setAlpha(i);
        this.mStrokePaint.setStrokeWidth(f);
        canvas.drawLine(f2, f3, f4, f5, this.mStrokePaint);
    }

    public void DrawRect(Canvas canvas, int i, int i2, int i3, int i4, float f, float f2, float f3, float f4, float f5) {
        this.mStrokePaint.setStrokeWidth(f);
        this.mStrokePaint.setColor(Color.rgb(i2, i3, i4));
        this.mStrokePaint.setAlpha(i);
        canvas.drawRect(f2, f3, f4, f5, this.mStrokePaint);
    }

    public void DrawFilledRect(Canvas canvas, int i, int i2, int i3, int i4, float f, float f2, float f3, float f4) {
        this.mFilledPaint.setColor(Color.rgb(i2, i3, i4));
        this.mFilledPaint.setAlpha(i);
        canvas.drawRect(f, f2, f3, f4, this.mFilledPaint);
    }

    public void DrawFilledRect1(Canvas canvas, int i, int i2, int i3, int i4, float f, float f2, float f3, float f4) {
        this.mFilledPaint.setColor(Color.rgb(i2, i3, i4));
        this.mFilledPaint.setAlpha(i);
        canvas.drawRect(f, f2, f + f3, f2 + f4, this.mFilledPaint);
    }

    public void DebugText(String str) {
        System.out.println(str);
    }

    public void DrawText(Canvas canvas, int i, int i2, int i3, int i4, String str, float f, float f2, float f3) {
        this.mTextPaint.setARGB(i, i2, i3, i4);
        this.mTextPaint.setTextSize(f3);
        canvas.drawText(str, f, f2, this.mTextPaint);
    }

    public void DrawWeapon(Canvas canvas, int i, int i2, int i3, int i4, int i5, int i6, float f, float f2, float f3) {
        this.mTextPaint.setARGB(i, i2, i3, i4);
        this.mTextPaint.setTextSize(f3);
        String weapon = getWeapon(i5);
        if (weapon != null) {
            canvas.drawText(weapon + ": " + i6, f, f2, this.mTextPaint);
        }
    }

    public void DrawName(Canvas canvas, int i, int i2, int i3, int i4, String str, int i5, float f, float f2, float f3) {
        String[] split = str.split(":");
        char[] cArr = new char[split.length];
        for (int i6 = 0; i6 < split.length; i6++) {
            cArr[i6] = (char) Integer.parseInt(split[i6]);
        }
        String str2 = new String(cArr);
        this.mTextPaint.setARGB(i, i2, i3, i4);
        this.mTextPaint.setTextSize(f3);
        canvas.drawText(str2, f, f2, this.mTextPaint);
    }

    public void DrawItems(Canvas canvas, String str, float f, float f2, float f3, float f4) {
        String itemName = getItemName(str);
        this.mTextPaint.setTextSize(f4);
        if (itemName != null && !itemName.equals("")) {
            canvas.drawText(itemName + " (" + Math.round(f) + "m)", f2, f3, this.mTextPaint);
        }
    }

    public void DrawVehicles(Canvas canvas, String str, float f, float f2, float f3, float f4) {
        String vehicleName = getVehicleName(str);
        this.mTextPaint.setColor(-1);
        this.mTextPaint.setAlpha(Opcodes.FCMPG);
        this.mTextPaint.setTextSize(f4);
        if (vehicleName != null && !vehicleName.equals("")) {
            canvas.drawText(vehicleName + ": " + Math.round(f) + "m", f2, f3, this.mTextPaint);
        }
    }

    public void DrawCircle(Canvas canvas, int i, int i2, int i3, int i4, float f, float f2, float f3, float f4) {
        this.mStrokePaint.setARGB(i, i2, i3, i4);
        this.mStrokePaint.setStrokeWidth(f4);
        canvas.drawCircle(f, f2, f3, this.mStrokePaint);
    }

    public void DrawFilledCircle(Canvas canvas, int i, int i2, int i3, int i4, float f, float f2, float f3) {
        this.mFilledPaint.setColor(Color.rgb(i2, i3, i4));
        this.mFilledPaint.setAlpha(i);
        canvas.drawCircle(f, f2, f3, this.mFilledPaint);
    }

    private String getItemName(String str) {
        if (str.contains("MZJ_8X") && e.getConfig("8x")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "8x";
        } else if (str.contains("MZJ_2X") && e.getConfig("2x")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "2x";
        } else if (str.contains("MZJ_HD") && e.getConfig("Red Dot")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Red Dot";
        } else if (str.contains("MZJ_3X") && e.getConfig("3x")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "3X";
        } else if (str.contains("MZJ_QX") && e.getConfig("Hollow")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Hollow Sight";
        } else if (str.contains("MZJ_6X") && e.getConfig("6x")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "6x";
        } else if (str.contains("MZJ_4X") && e.getConfig("4x")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "4x";
        } else if (str.contains("MZJ_SideRMR") && e.getConfig("Canted")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Canted Sight";
        } else if (str.contains("AUG") && e.getConfig("AUG")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "AUG";
        } else if (str.contains("M762") && e.getConfig("M762")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "M762";
        } else if (str.contains("SCAR") && e.getConfig("SCAR-L")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "SCAR-L";
        } else if (str.contains("M416") && e.getConfig("M416")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "M416";
        } else if (str.contains("M16A4") && e.getConfig("M16A4")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "M16A-4";
        } else if (str.contains("Mk47") && e.getConfig("Mk47 Mutant")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Mk47 Mutant";
        } else if (str.contains("G36") && e.getConfig("G36C")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "G36C";
        } else if (str.contains("QBZ") && e.getConfig("QBZ")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "QBZ";
        } else if (str.contains("AKM") && e.getConfig("AKM")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "AKM";
        } else if (str.contains("Groza") && e.getConfig("Groza")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Groza";
        } else if (str.contains("PP19") && e.getConfig("Bizon")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Bizon";
        } else if (str.contains("TommyGun") && e.getConfig("TommyGun")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "TommyGun";
        } else if (str.contains("MP5K") && e.getConfig("MP5K")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "MP5K";
        } else if (str.contains("UMP9") && e.getConfig("UMP")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "UMP";
        } else if (str.contains("Vector") && e.getConfig("Vector")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Vector";
        } else if (str.contains("MachineGun_Uzi") && e.getConfig("Uzi")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Uzi";
        } else if (str.contains("DP28") && e.getConfig("DP28")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "DP28";
        } else if (str.contains("M249") && e.getConfig("M249")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "M249";
        } else if (str.contains("AWM") && e.getConfig("AWM")) {
            this.mTextPaint.setColor(-1);
            return "AWM";
        } else if (str.contains("QBU") && e.getConfig("QBU")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "QBU";
        } else if (str.contains("SLR") && e.getConfig("SLR")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "SLR";
        } else if (str.contains("SKS") && e.getConfig("SKS")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "SKS";
        } else if (str.contains("Mini14") && e.getConfig("Mini14")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Mini14";
        } else if (str.contains("M24") && e.getConfig("M24")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "M24";
        } else if (str.contains("Kar98k") && e.getConfig("Kar98k")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Kar98k";
        } else if (str.contains("VSS") && e.getConfig("VSS")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "VSS";
        } else if (str.contains("Win94") && e.getConfig("Win94")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Win94";
        } else if (str.contains("Mk14") && e.getConfig("Mk14")) {
            this.mTextPaint.setColor(-1);
            return "Mk14";
        } else if (str.contains("S12K") && e.getConfig("S12K")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "S12K";
        } else if (str.contains("DBS") && e.getConfig("DBS")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "DBS";
        } else if (str.contains("S686") && e.getConfig("S686")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "S686";
        } else if (str.contains("S1897") && e.getConfig("S1897")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "S1897";
        } else if (str.contains("Sickle") && e.getConfig("Sickle")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Sickle";
        } else if (str.contains("Machete") && e.getConfig("Machete")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Machete";
        } else if (str.contains("Cowbar") && e.getConfig("Cowbar")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Cowbar";
        } else if (str.contains("CrossBow") && e.getConfig("CrossBow")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "CrossBow";
        } else if (str.contains("Pan") && e.getConfig("Pan")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Pan";
        } else if (str.contains("SawedOff") && e.getConfig("SawedOff")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "SawedOff";
        } else if (str.contains("R1895") && e.getConfig("R1895")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "R1895";
        } else if (str.contains("Vz61") && e.getConfig("Vz61")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Vz61";
        } else if (str.contains("P92") && e.getConfig("P92")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "P92";
        } else if (str.contains("P18C") && e.getConfig("P18C")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "P18C";
        } else if (str.contains("R45") && e.getConfig("R45")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "R45";
        } else if (str.contains("P1911") && e.getConfig("P1911")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "P1911";
        } else if (str.contains("DesertEagle") && e.getConfig("Desert Eagle")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "DesertEagle";
        } else if (str.contains("Ammo_762mm") && e.getConfig("7.62")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "7.62";
        } else if (str.contains("Ammo_45AC") && e.getConfig("45ACP")) {
            this.mTextPaint.setColor(-1);
            return "45ACP";
        } else if (str.contains("Ammo_556mm") && e.getConfig("5.56")) {
            this.mTextPaint.setColor(-1);
            return "5.56";
        } else if (str.contains("Ammo_9mm") && e.getConfig("9mm")) {
            this.mTextPaint.setColor(-1);
            return "9mm";
        } else if (str.contains("Ammo_300Magnum") && e.getConfig("300Magnum")) {
            this.mTextPaint.setColor(-1);
            return "300Magnum";
        } else if (str.contains("Ammo_12Guage") && e.getConfig("12 Guage")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "12 Guage";
        } else if (str.contains("Ammo_Bolt") && e.getConfig("Arrow")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Arrow";
        } else if (str.contains("Bag_Lv3") && e.getConfig("Bag L 3")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Bag lvl 3";
        } else if (str.contains("Bag_Lv1") && e.getConfig("Bag L 1")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Bag lvl 1";
        } else if (str.contains("Bag_Lv2") && e.getConfig("Bag L 2")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Bag lvl 2";
        } else if (str.contains("Armor_Lv2") && e.getConfig("Vest L 2")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Vest lvl 2";
        } else if (str.contains("Armor_Lv1") && e.getConfig("Vest L 1")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Vest lvl 1";
        } else if (str.contains("Armor_Lv3") && e.getConfig("Vest L 3")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Vest lvl 3";
        } else if (str.contains("Helmet_Lv2") && e.getConfig("Helmet 2")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Helmet lvl 2";
        } else if (str.contains("Helmet_Lv1") && e.getConfig("Helmet 1")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Helmet lvl 1";
        } else if (str.contains("Helmet_Lv3") && e.getConfig("Helmet 3")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Helmet lvl 3";
        } else if (str.contains("Pills") && e.getConfig("PainKiller")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Painkiller";
        } else if (str.contains("Injection") && e.getConfig("Adrenaline")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Adrenaline";
        } else if (str.contains("Drink") && e.getConfig("Energy Drink")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Energy Drink";
        } else if (str.contains("Firstaid") && e.getConfig("FirstAidKit")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "FirstAidKit";
        } else if (str.contains("Bandage") && e.getConfig("Bandage")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Bandage";
        } else if (str.contains("FirstAidbox") && e.getConfig("Medkit")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Medkit";
        } else if (str.contains("Grenade_Stun") && e.getConfig("Stung")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Stung";
        } else if (str.contains("Grenade_Shoulei") && e.getConfig("Grenade")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Grenade";
        } else if (str.contains("Grenade_Smoke") && e.getConfig("Smoke")) {
            this.mTextPaint.setColor(-1);
            return "Smoke";
        } else if (str.contains("Grenade_Burn") && e.getConfig("Molotov")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Molotov";
        } else if (str.contains("Large_FlashHider") && e.getConfig("Flash Hider Ar")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Flash Hider Ar";
        } else if (str.contains("QK_Large_C") && e.getConfig("Ar Compensator")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ar Compensator";
        } else if (str.contains("Mid_FlashHider") && e.getConfig("Flash Hider SMG")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Flash Hider SMG";
        } else if (str.contains("QT_A_") && e.getConfig("Tactical Stock")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Tactical Stock";
        } else if (str.contains("DuckBill") && e.getConfig("Duckbill")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "DuckBill";
        } else if (str.contains("Sniper_FlashHider") && e.getConfig("Flash Hider Snp")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Flash Hider Sniper";
        } else if (str.contains("Mid_Suppressor") && e.getConfig("Suppressor SMG")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Suppressor SMG";
        } else if (str.contains("HalfGrip") && e.getConfig("Half Grip")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Half Grip";
        } else if (str.contains("Choke") && e.getConfig("Choke")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Choke";
        } else if (str.contains("QT_UZI") && e.getConfig("Stock Micro UZI")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Stock Micro UZI";
        } else if (str.contains("QK_Sniper") && e.getConfig("SniperCompensator")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Sniper Compensator";
        } else if (str.contains("Sniper_Suppressor") && e.getConfig("Sup Sniper")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Suppressor Sniper";
        } else if (str.contains("Large_Suppressor") && e.getConfig("Suppressor Ar")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Suppressor Ar";
        } else if (str.contains("Sniper_EQ_") && e.getConfig("Ex.Qd.Sniper")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ex.Qd.Sniper";
        } else if (str.contains("Mid_Q_") && e.getConfig("Qd.SMG")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Qd.SMG";
        } else if (str.contains("Mid_E_") && e.getConfig("Ex.SMG")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ex.SMG";
        } else if (str.contains("Sniper_Q_") && e.getConfig("Qd.Sniper")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Qd.Sniper";
        } else if (str.contains("Sniper_E_") && e.getConfig("Ex.Sniper")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ex.Sniper";
        } else if (str.contains("Large_E_") && e.getConfig("Ex.Ar")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ex.Ar";
        } else if (str.contains("Large_EQ_") && e.getConfig("Ex.Qd.Ar")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ex.Qd.Ar";
        } else if (str.contains("Large_Q_") && e.getConfig("Qd.Ar")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Qd.Ar";
        } else if (str.contains("Mid_EQ_") && e.getConfig("Ex.Qd.SMG")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ex.Qd.SMG";
        } else if (str.contains("Crossbow_Q") && e.getConfig("Quiver CrossBow")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Quiver CrossBow";
        } else if (str.contains("ZDD_Sniper") && e.getConfig("Bullet Loop")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Bullet Loop";
        } else if (str.contains("ThumbGrip") && e.getConfig("Thumb Grip")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Thumb Grip";
        } else if (str.contains("Lasersight") && e.getConfig("Laser Sight")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Laser Sight";
        } else if (str.contains("Angled") && e.getConfig("Angled Grip")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Angled Grip";
        } else if (str.contains("LightGrip") && e.getConfig("Light Grip")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Light Grip";
        } else if (str.contains("Vertical") && e.getConfig("Vertical Grip")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Vertical Grip";
        } else if (str.contains("GasCan") && e.getConfig("Gas Can")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Gas Can";
        } else if (str.contains("Mid_Compensator") && e.getConfig("Compensator SMG")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Compensator SMG";
        } else if (str.contains("Flare") && e.getConfig("Flare Gun")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Flare Gun";
        } else if (str.contains("Ghillie") && e.getConfig("Ghillie Suit")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Ghillie Suit";
        } else if (str.contains("CheekPad") && e.getConfig("CheekPad")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "CheekPad";
        } else if (str.contains("PickUpListWrapperActor") && e.getConfig("Crate")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "Crate";
        } else if (str.contains("AirDropPlane") && e.getConfig("DropPlane")) {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "DropPlane";
        } else if (!str.contains("AirDrop") || !e.getConfig("AirDrop")) {
            return null;
        } else {
            this.mTextPaint.setARGB(255, 255, 255, 255);
            return "AirDrop";
        }
    }

    private String getVehicleName(String str) {
        if (str.contains("Buggy") && e.getConfig("Buggy")) {
            return "Buggy";
        }
        if (str.contains("UAZ") && e.getConfig("UAZ")) {
            return "UAZ";
        }
        if (str.contains("MotorcycleC") && e.getConfig("Trike")) {
            return "Trike";
        }
        if (str.contains("Motorcycle") && e.getConfig("Bike")) {
            return "Bike";
        }
        if (str.contains("Dacia") && e.getConfig("Dacia")) {
            return "Dacia";
        }
        if (str.contains("AquaRail") && e.getConfig("Jet")) {
            return "Jet";
        }
        if (str.contains("PG117") && e.getConfig("Boat")) {
            return "Boat";
        }
        if (str.contains("MiniBus") && e.getConfig("Bus")) {
            return "Bus";
        }
        if (str.contains("Mirado") && e.getConfig("Mirado")) {
            return "Mirado";
        }
        if (str.contains("Scooter") && e.getConfig("Scooter")) {
            return "Scooter";
        }
        if (str.contains("Rony") && e.getConfig("Rony")) {
            return "Rony";
        }
        if (str.contains("Snowbike") && e.getConfig("Snowbike")) {
            return "Snowbike";
        }
        if (str.contains("Snowmobile") && e.getConfig("Snowmobile")) {
            return "Snowmobile";
        }
        if (str.contains("Tuk") && e.getConfig("Tempo")) {
            return "Tempo";
        }
        if (str.contains("PickUp") && e.getConfig("Truck")) {
            return "Truck";
        }
        if (str.contains("BRDM") && e.getConfig("BRDM")) {
            return "BRDM";
        }
        if (!str.contains("LadaNiva") || !e.getConfig("LadaNiva")) {
            return (!str.contains("Bigfoot") || !e.getConfig("Monster Truck")) ? "" : "Monster Truck";
        }
        return "LadaNiva";
    }
}
