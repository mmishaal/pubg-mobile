package com.amazon.kindelx;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;
import androidx.core.view.ViewCompat;

import com.AuToCheaTs.Free.R;

/* renamed from: com.amazon.kindelx.b */
public class b extends Service implements View.OnClickListener {
    private static b Instance;
    View espView;
    View logoView;
    /* access modifiers changed from: private */
    public View mFloatingView;
    /* access modifiers changed from: private */
    public View mFloatingView2;
    /* access modifiers changed from: private */
    public WindowManager mWindowManager;
    /* access modifiers changed from: private */
    public WindowManager mWindowManager2;

    public native void AimBy(int i);

    public native void AimWhen(int i);

    public native void Range(int i);

    public native void SettingValue(int i, boolean z);

    public native void Target(int i);

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onClick(View view) {
    }

    static {
        System.loadLibrary("native-lib");
    }

    public void onCreate() {
        super.onCreate();
        Instance = this;
        createOver();
        this.logoView = this.mFloatingView.findViewById(R.id.relativeLayoutParent);
        this.espView = this.mFloatingView.findViewById(R.id.espView);
        Init();
    }

    /* access modifiers changed from: package-private */
    @SuppressLint("WrongConstant")
    public void createOver2() {
        this.mFloatingView2 = LayoutInflater.from(this).inflate(R.layout.floatlog2, (ViewGroup) null);
        final WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 8, 1);
        layoutParams.gravity = 51;
        layoutParams.x = 650;
        layoutParams.y = 100;
        this.mWindowManager2 = (WindowManager) getSystemService("window");
        this.mWindowManager2.addView(this.mFloatingView2, layoutParams);
        this.mFloatingView2.findViewById(R.id.relativeLayoutParent2).setOnTouchListener(new View.OnTouchListener() {
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                int action = motionEvent.getAction();
                if (action == 0) {
                    this.initialX = layoutParams.x;
                    this.initialY = layoutParams.y;
                    this.initialTouchX = motionEvent.getRawX();
                    this.initialTouchY = motionEvent.getRawY();
                    return true;
                } else if (action != 2) {
                    return false;
                } else {
                    layoutParams.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                    layoutParams.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));
                    b.this.mWindowManager2.updateViewLayout(b.this.mFloatingView2, layoutParams);
                    return true;
                }
            }
        });
        ((ToggleButton) this.mFloatingView2.findViewById(R.id.AIMSHOW)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    b.this.SettingValue(11, true);
                } else {
                    b.this.SettingValue(11, false);
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    @SuppressLint("WrongConstant")
    public void createOver() {
        this.mFloatingView = LayoutInflater.from(this).inflate(R.layout.float_logo, (ViewGroup) null);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, Build.VERSION.SDK_INT >= 26 ? 2038 : 2002, 8, 1);
        this.mWindowManager = (WindowManager) getSystemService("window");
        this.mWindowManager.addView(this.mFloatingView, layoutParams);
        final GestureDetector gestureDetector = new GestureDetector(this, new SingleTapConfirm());
        ((TextView) this.mFloatingView.findViewById(R.id.closeBtn)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                b.this.espView.setVisibility(8);
                b.this.logoView.setVisibility(0);
            }
        });
        TextView textView = (TextView) this.mFloatingView.findViewById(R.id.playerBtn);
        TextView textView2 = (TextView) this.mFloatingView.findViewById(R.id.itemBtn);
        TextView textView3 = (TextView) this.mFloatingView.findViewById(R.id.vehicleBtn);
        final TextView textView4 = textView2;
        final TextView textView5 = textView;
        final TextView textView6 = textView3;
        final LinearLayout linearLayout = (LinearLayout) this.mFloatingView.findViewById(R.id.items);
        final LinearLayout linearLayout2 = (LinearLayout) this.mFloatingView.findViewById(R.id.players);
        TextView textView7 = textView3;
        final LinearLayout linearLayout3 = (LinearLayout) this.mFloatingView.findViewById(R.id.vehicles);
         new View.OnClickListener() {
            public void onClick(View view) {
                textView4.setBackgroundColor(Color.parseColor("#E4E4E4"));
                textView5.setBackgroundColor(Color.parseColor("#150432"));
                textView6.setBackgroundColor(Color.parseColor("#F3F3F3"));
                textView5.setTextColor(Color.parseColor("#5EE863"));
                textView4.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                textView6.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                linearLayout.setVisibility(8);
                linearLayout2.setVisibility(0);
                linearLayout3.setVisibility(8);
            }
        };
        final TextView textView8 = textView7;
        textView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                textView4.setBackgroundColor(Color.parseColor("#150432"));
                textView5.setBackgroundColor(Color.parseColor("#D5D5D5"));
                textView8.setBackgroundColor(Color.parseColor("#F3F3F3"));
                textView5.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                textView4.setTextColor(Color.parseColor("#5EE863"));
                textView8.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                linearLayout.setVisibility(0);
                linearLayout2.setVisibility(8);
                linearLayout3.setVisibility(8);
            }
        });
        textView7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                textView4.setBackgroundColor(Color.parseColor("#E4E4E4"));
                textView5.setBackgroundColor(Color.parseColor("#D5D5D5"));
                textView8.setBackgroundColor(Color.parseColor("#150432"));
                textView5.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                textView4.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                textView8.setTextColor(Color.parseColor("#5EE863"));
                linearLayout.setVisibility(8);
                linearLayout2.setVisibility(8);
                linearLayout3.setVisibility(0);
            }
        });
        final WindowManager.LayoutParams layoutParams2 = layoutParams;
        this.mFloatingView.findViewById(R.id.relativeLayoutParent).setOnTouchListener(new View.OnTouchListener() {
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (gestureDetector.onTouchEvent(motionEvent)) {
                    b.this.espView.setVisibility(0);
                    b.this.logoView.setVisibility(8);
                    return true;
                }
                int action = motionEvent.getAction();
                if (action == 0) {
                    this.initialX = layoutParams2.x;
                    this.initialY = layoutParams2.y;
                    this.initialTouchX = motionEvent.getRawX();
                    this.initialTouchY = motionEvent.getRawY();
                    return true;
                } else if (action != 2) {
                    return false;
                } else {
                    layoutParams2.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                    layoutParams2.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));
                    b.this.mWindowManager.updateViewLayout(b.this.mFloatingView, layoutParams2);
                    return true;
                }
            }
        });
    }

    public void onDestroy() {
        super.onDestroy();
        View view = this.mFloatingView;
        if (view != null) {
            this.mWindowManager.removeView(view);
        }
        View view2 = this.mFloatingView2;
        if (view2 != null) {
            this.mWindowManager2.removeView(view2);
        }
    }

    private String getType() {
        return getSharedPreferences("espValue", 0).getString("type", "1");
    }

    /* access modifiers changed from: private */
    public void setValue(String str, boolean z) {
        SharedPreferences.Editor edit = getSharedPreferences("espValue", 0).edit();
        edit.putBoolean(str, z);
        edit.apply();
    }

    /* access modifiers changed from: package-private */
    public boolean getConfig(String str) {
        return getSharedPreferences("espValue", 0).getBoolean(str, false);
    }

    /* access modifiers changed from: package-private */
    public void setFps(int i) {
        SharedPreferences.Editor edit = getSharedPreferences("espValue", 0).edit();
        edit.putInt("fps", i);
        edit.apply();
    }

    /* access modifiers changed from: package-private */
    public int getFps() {
        return getSharedPreferences("espValue", 0).getInt("fps", 100);
    }

    public static void HideFloat() {
        b bVar = Instance;
        if (bVar != null) {
            bVar.Hide();
        }
    }

    public void Hide() {
        stopSelf();
        System.exit(-1);
    }

    /* access modifiers changed from: package-private */
    public void Init() {
        final CheckBox checkBox = (CheckBox) this.mFloatingView.findViewById(R.id.Buggy);
        checkBox.setChecked(getConfig((String) checkBox.getText()));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox.getText()), checkBox.isChecked());
            }
        });
        final CheckBox checkBox2 = (CheckBox) this.mFloatingView.findViewById(R.id.UAZ);
        checkBox2.setChecked(getConfig((String) checkBox2.getText()));
        checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox2.getText()), checkBox2.isChecked());
            }
        });
        final CheckBox checkBox3 = (CheckBox) this.mFloatingView.findViewById(R.id.Trike);
        checkBox3.setChecked(getConfig((String) checkBox3.getText()));
        checkBox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox3.getText()), checkBox3.isChecked());
            }
        });
        final CheckBox checkBox4 = (CheckBox) this.mFloatingView.findViewById(R.id.Bike);
        checkBox4.setChecked(getConfig((String) checkBox4.getText()));
        checkBox4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox4.getText()), checkBox4.isChecked());
            }
        });
        final CheckBox checkBox5 = (CheckBox) this.mFloatingView.findViewById(R.id.Dacia);
        checkBox5.setChecked(getConfig((String) checkBox5.getText()));
        checkBox5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox5.getText()), checkBox5.isChecked());
            }
        });
        final CheckBox checkBox6 = (CheckBox) this.mFloatingView.findViewById(R.id.Jet);
        checkBox6.setChecked(getConfig((String) checkBox6.getText()));
        checkBox6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox6.getText()), checkBox6.isChecked());
            }
        });
        final CheckBox checkBox7 = (CheckBox) this.mFloatingView.findViewById(R.id.Boat);
        checkBox7.setChecked(getConfig((String) checkBox7.getText()));
        checkBox7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox7.getText()), checkBox7.isChecked());
            }
        });
        final CheckBox checkBox8 = (CheckBox) this.mFloatingView.findViewById(R.id.Scooter);
        checkBox8.setChecked(getConfig((String) checkBox8.getText()));
        checkBox8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox8.getText()), checkBox8.isChecked());
            }
        });
        final CheckBox checkBox9 = (CheckBox) this.mFloatingView.findViewById(R.id.Bus);
        checkBox9.setChecked(getConfig((String) checkBox9.getText()));
        checkBox9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox9.getText()), checkBox9.isChecked());
            }
        });
        final CheckBox checkBox10 = (CheckBox) this.mFloatingView.findViewById(R.id.Mirado);
        checkBox10.setChecked(getConfig((String) checkBox10.getText()));
        checkBox10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox10.getText()), checkBox10.isChecked());
            }
        });
        final CheckBox checkBox11 = (CheckBox) this.mFloatingView.findViewById(R.id.Rony);
        checkBox11.setChecked(getConfig((String) checkBox11.getText()));
        checkBox11.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox11.getText()), checkBox11.isChecked());
            }
        });
        final CheckBox checkBox12 = (CheckBox) this.mFloatingView.findViewById(R.id.Snowbike);
        checkBox12.setChecked(getConfig((String) checkBox12.getText()));
        checkBox12.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox12.getText()), checkBox12.isChecked());
            }
        });
        final CheckBox checkBox13 = (CheckBox) this.mFloatingView.findViewById(R.id.Snowmobile);
        checkBox13.setChecked(getConfig((String) checkBox13.getText()));
        checkBox13.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox13.getText()), checkBox13.isChecked());
            }
        });
        final CheckBox checkBox14 = (CheckBox) this.mFloatingView.findViewById(R.id.Tempo);
        checkBox14.setChecked(getConfig((String) checkBox14.getText()));
        checkBox14.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox14.getText()), checkBox14.isChecked());
            }
        });
        final CheckBox checkBox15 = (CheckBox) this.mFloatingView.findViewById(R.id.Truck);
        checkBox15.setChecked(getConfig((String) checkBox15.getText()));
        checkBox15.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox15.getText()), checkBox15.isChecked());
            }
        });
        final CheckBox checkBox16 = (CheckBox) this.mFloatingView.findViewById(R.id.MonsterTruck);
        checkBox16.setChecked(getConfig((String) checkBox16.getText()));
        checkBox16.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox16.getText()), checkBox16.isChecked());
            }
        });
        final CheckBox checkBox17 = (CheckBox) this.mFloatingView.findViewById(R.id.BRDM);
        checkBox17.setChecked(getConfig((String) checkBox17.getText()));
        checkBox17.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox17.getText()), checkBox17.isChecked());
            }
        });
        final CheckBox checkBox18 = (CheckBox) this.mFloatingView.findViewById(R.id.LadaNiva);
        checkBox18.setChecked(getConfig((String) checkBox18.getText()));
        checkBox18.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox18.getText()), checkBox18.isChecked());
            }
        });
        final CheckBox checkBox19 = (CheckBox) this.mFloatingView.findViewById(R.id.CheekPad);
        checkBox19.setChecked(getConfig((String) checkBox19.getText()));
        checkBox19.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox19.getText()), checkBox19.isChecked());
            }
        });
        final CheckBox checkBox20 = (CheckBox) this.mFloatingView.findViewById(R.id.AirDrop);
        checkBox20.setChecked(getConfig((String) checkBox20.getText()));
        checkBox20.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox20.getText()), checkBox20.isChecked());
            }
        });
        final CheckBox checkBox21 = (CheckBox) this.mFloatingView.findViewById(R.id.Crate);
        checkBox21.setChecked(getConfig((String) checkBox21.getText()));
        checkBox21.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox21.getText()), checkBox21.isChecked());
            }
        });
        final CheckBox checkBox22 = (CheckBox) this.mFloatingView.findViewById(R.id.DropPlane);
        checkBox22.setChecked(getConfig((String) checkBox22.getText()));
        checkBox22.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox22.getText()), checkBox22.isChecked());
            }
        });
        final Switch switchR = (Switch) this.mFloatingView.findViewById(R.id.isEnemyWeapon);
        switchR.setChecked(getConfig((String) switchR.getText()));
        SettingValue(10, getConfig((String) switchR.getText()));
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR.getText()), switchR.isChecked());
                b.this.SettingValue(10, switchR.isChecked());
            }
        });
        final Switch switchR2 = (Switch) this.mFloatingView.findViewById(R.id.isGrenadeWarning);
        switchR2.setChecked(getConfig((String) switchR2.getText()));
        SettingValue(9, getConfig((String) switchR2.getText()));
        switchR2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR2.getText()), switchR2.isChecked());
                b.this.SettingValue(9, switchR2.isChecked());
            }
        });
        final Switch switchR3 = (Switch) this.mFloatingView.findViewById(R.id.isSkelton);
        switchR3.setChecked(getConfig((String) switchR3.getText()));
        SettingValue(8, getConfig((String) switchR3.getText()));
        switchR3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR3.getText()), switchR3.isChecked());
                b.this.SettingValue(8, switchR3.isChecked());
            }
        });
        final Switch switchR4 = (Switch) this.mFloatingView.findViewById(R.id.isHead);
        switchR4.setChecked(getConfig((String) switchR4.getText()));
        SettingValue(6, getConfig((String) switchR4.getText()));
        switchR4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR4.getText()), switchR4.isChecked());
                b.this.SettingValue(6, switchR4.isChecked());
            }
        });
        final Switch switchR5 = (Switch) this.mFloatingView.findViewById(R.id.isBox);
        switchR5.setChecked(getConfig((String) switchR5.getText()));
        SettingValue(1, getConfig((String) switchR5.getText()));
        switchR5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR5.getText()), switchR5.isChecked());
                b.this.SettingValue(1, switchR5.isChecked());
            }
        });
        final Switch switchR6 = (Switch) this.mFloatingView.findViewById(R.id.isLine);
        switchR6.setChecked(getConfig((String) switchR6.getText()));
        SettingValue(2, getConfig((String) switchR6.getText()));
        switchR6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR6.getText()), switchR6.isChecked());
                b.this.SettingValue(2, switchR6.isChecked());
            }
        });
        final Switch switchR7 = (Switch) this.mFloatingView.findViewById(R.id.isBack);
        switchR7.setChecked(getConfig((String) switchR7.getText()));
        SettingValue(7, getConfig((String) switchR7.getText()));
        switchR7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR7.getText()), switchR7.isChecked());
                b.this.SettingValue(7, switchR7.isChecked());
            }
        });
        final Switch switchR8 = (Switch) this.mFloatingView.findViewById(R.id.isHealth);
        switchR8.setChecked(getConfig((String) switchR8.getText()));
        SettingValue(4, getConfig((String) switchR8.getText()));
        switchR8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR8.getText()), switchR8.isChecked());
                b.this.SettingValue(4, switchR8.isChecked());
            }
        });
        final Switch switchR9 = (Switch) this.mFloatingView.findViewById(R.id.isName);
        switchR9.setChecked(getConfig((String) switchR9.getText()));
        SettingValue(5, getConfig((String) switchR9.getText()));
        switchR9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR9.getText()), switchR9.isChecked());
                b.this.SettingValue(5, switchR9.isChecked());
            }
        });
        final Switch switchR10 = (Switch) this.mFloatingView.findViewById(R.id.isDist);
        switchR10.setChecked(getConfig((String) switchR10.getText()));
        SettingValue(3, getConfig((String) switchR10.getText()));
        switchR10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR10.getText()), switchR10.isChecked());
                b.this.SettingValue(3, switchR10.isChecked());
            }
        });
        final CheckBox checkBox23 = (CheckBox) this.mFloatingView.findViewById(R.id.canted);
        checkBox23.setChecked(getConfig((String) checkBox23.getText()));
        checkBox23.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox23.getText()), checkBox23.isChecked());
            }
        });
        final CheckBox checkBox24 = (CheckBox) this.mFloatingView.findViewById(R.id.reddot);
        checkBox24.setChecked(getConfig((String) checkBox24.getText()));
        checkBox24.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox24.getText()), checkBox24.isChecked());
            }
        });
        final CheckBox checkBox25 = (CheckBox) this.mFloatingView.findViewById(R.id.hollow);
        checkBox25.setChecked(getConfig((String) checkBox25.getText()));
        checkBox25.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox25.getText()), checkBox25.isChecked());
            }
        });
        final CheckBox checkBox26 = (CheckBox) this.mFloatingView.findViewById(R.id.twox);
        checkBox26.setChecked(getConfig((String) checkBox26.getText()));
        checkBox26.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox26.getText()), checkBox26.isChecked());
            }
        });
        final CheckBox checkBox27 = (CheckBox) this.mFloatingView.findViewById(R.id.threex);
        checkBox27.setChecked(getConfig((String) checkBox27.getText()));
        checkBox27.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox27.getText()), checkBox27.isChecked());
            }
        });
        final CheckBox checkBox28 = (CheckBox) this.mFloatingView.findViewById(R.id.fourx);
        checkBox28.setChecked(getConfig((String) checkBox28.getText()));
        checkBox28.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox28.getText()), checkBox28.isChecked());
            }
        });
        final CheckBox checkBox29 = (CheckBox) this.mFloatingView.findViewById(R.id.sixx);
        checkBox29.setChecked(getConfig((String) checkBox29.getText()));
        checkBox29.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox29.getText()), checkBox29.isChecked());
            }
        });
        final CheckBox checkBox30 = (CheckBox) this.mFloatingView.findViewById(R.id.eightx);
        checkBox30.setChecked(getConfig((String) checkBox30.getText()));
        checkBox30.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox30.getText()), checkBox30.isChecked());
            }
        });
        final CheckBox checkBox31 = (CheckBox) this.mFloatingView.findViewById(R.id.AWM);
        checkBox31.setChecked(getConfig((String) checkBox31.getText()));
        checkBox31.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox31.getText()), checkBox31.isChecked());
            }
        });
        final CheckBox checkBox32 = (CheckBox) this.mFloatingView.findViewById(R.id.QBU);
        checkBox32.setChecked(getConfig((String) checkBox32.getText()));
        checkBox32.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox32.getText()), checkBox32.isChecked());
            }
        });
        final CheckBox checkBox33 = (CheckBox) this.mFloatingView.findViewById(R.id.SLR);
        checkBox33.setChecked(getConfig((String) checkBox33.getText()));
        checkBox33.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox33.getText()), checkBox33.isChecked());
            }
        });
        final CheckBox checkBox34 = (CheckBox) this.mFloatingView.findViewById(R.id.SKS);
        checkBox34.setChecked(getConfig((String) checkBox34.getText()));
        checkBox34.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox34.getText()), checkBox34.isChecked());
            }
        });
        final CheckBox checkBox35 = (CheckBox) this.mFloatingView.findViewById(R.id.Mini14);
        checkBox35.setChecked(getConfig((String) checkBox35.getText()));
        checkBox35.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox35.getText()), checkBox35.isChecked());
            }
        });
        final CheckBox checkBox36 = (CheckBox) this.mFloatingView.findViewById(R.id.M24);
        checkBox36.setChecked(getConfig((String) checkBox36.getText()));
        checkBox36.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox36.getText()), checkBox36.isChecked());
            }
        });
        final CheckBox checkBox37 = (CheckBox) this.mFloatingView.findViewById(R.id.Kar98k);
        checkBox37.setChecked(getConfig((String) checkBox37.getText()));
        checkBox37.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox37.getText()), checkBox37.isChecked());
            }
        });
        final CheckBox checkBox38 = (CheckBox) this.mFloatingView.findViewById(R.id.VSS);
        checkBox38.setChecked(getConfig((String) checkBox38.getText()));
        checkBox38.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox38.getText()), checkBox38.isChecked());
            }
        });
        final CheckBox checkBox39 = (CheckBox) this.mFloatingView.findViewById(R.id.Win94);
        checkBox39.setChecked(getConfig((String) checkBox39.getText()));
        checkBox39.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox39.getText()), checkBox39.isChecked());
            }
        });
        final CheckBox checkBox40 = (CheckBox) this.mFloatingView.findViewById(R.id.AUG);
        checkBox40.setChecked(getConfig((String) checkBox40.getText()));
        checkBox40.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox40.getText()), checkBox40.isChecked());
            }
        });
        final CheckBox checkBox41 = (CheckBox) this.mFloatingView.findViewById(R.id.M762);
        checkBox41.setChecked(getConfig((String) checkBox41.getText()));
        checkBox41.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox41.getText()), checkBox41.isChecked());
            }
        });
        final CheckBox checkBox42 = (CheckBox) this.mFloatingView.findViewById(R.id.SCARL);
        checkBox42.setChecked(getConfig((String) checkBox42.getText()));
        checkBox42.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox42.getText()), checkBox42.isChecked());
            }
        });
        final CheckBox checkBox43 = (CheckBox) this.mFloatingView.findViewById(R.id.M416);
        checkBox43.setChecked(getConfig((String) checkBox43.getText()));
        checkBox43.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox43.getText()), checkBox43.isChecked());
            }
        });
        final CheckBox checkBox44 = (CheckBox) this.mFloatingView.findViewById(R.id.M16A4);
        checkBox44.setChecked(getConfig((String) checkBox44.getText()));
        checkBox44.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox44.getText()), checkBox44.isChecked());
            }
        });
        final CheckBox checkBox45 = (CheckBox) this.mFloatingView.findViewById(R.id.Mk47Mutant);
        checkBox45.setChecked(getConfig((String) checkBox45.getText()));
        checkBox45.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox45.getText()), checkBox45.isChecked());
            }
        });
        final CheckBox checkBox46 = (CheckBox) this.mFloatingView.findViewById(R.id.G36C);
        checkBox46.setChecked(getConfig((String) checkBox46.getText()));
        checkBox46.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox46.getText()), checkBox46.isChecked());
            }
        });
        final CheckBox checkBox47 = (CheckBox) this.mFloatingView.findViewById(R.id.QBZ);
        checkBox47.setChecked(getConfig((String) checkBox47.getText()));
        checkBox47.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox47.getText()), checkBox47.isChecked());
            }
        });
        final CheckBox checkBox48 = (CheckBox) this.mFloatingView.findViewById(R.id.AKM);
        checkBox48.setChecked(getConfig((String) checkBox48.getText()));
        checkBox48.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox48.getText()), checkBox48.isChecked());
            }
        });
        final CheckBox checkBox49 = (CheckBox) this.mFloatingView.findViewById(R.id.Groza);
        checkBox49.setChecked(getConfig((String) checkBox49.getText()));
        checkBox49.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox49.getText()), checkBox49.isChecked());
            }
        });
        final CheckBox checkBox50 = (CheckBox) this.mFloatingView.findViewById(R.id.S12K);
        checkBox50.setChecked(getConfig((String) checkBox50.getText()));
        checkBox50.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox50.getText()), checkBox50.isChecked());
            }
        });
        final CheckBox checkBox51 = (CheckBox) this.mFloatingView.findViewById(R.id.DBS);
        checkBox51.setChecked(getConfig((String) checkBox51.getText()));
        checkBox51.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox51.getText()), checkBox51.isChecked());
            }
        });
        final CheckBox checkBox52 = (CheckBox) this.mFloatingView.findViewById(R.id.S686);
        checkBox52.setChecked(getConfig((String) checkBox52.getText()));
        checkBox52.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox52.getText()), checkBox52.isChecked());
            }
        });
        final CheckBox checkBox53 = (CheckBox) this.mFloatingView.findViewById(R.id.S1897);
        checkBox53.setChecked(getConfig((String) checkBox53.getText()));
        checkBox53.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox53.getText()), checkBox53.isChecked());
            }
        });
        final CheckBox checkBox54 = (CheckBox) this.mFloatingView.findViewById(R.id.SawedOff);
        checkBox54.setChecked(getConfig((String) checkBox54.getText()));
        checkBox54.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox54.getText()), checkBox54.isChecked());
            }
        });
        final CheckBox checkBox55 = (CheckBox) this.mFloatingView.findViewById(R.id.TommyGun);
        checkBox55.setChecked(getConfig((String) checkBox55.getText()));
        checkBox55.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox55.getText()), checkBox55.isChecked());
            }
        });
        final CheckBox checkBox56 = (CheckBox) this.mFloatingView.findViewById(R.id.MP5K);
        checkBox56.setChecked(getConfig((String) checkBox56.getText()));
        checkBox56.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox56.getText()), checkBox56.isChecked());
            }
        });
        final CheckBox checkBox57 = (CheckBox) this.mFloatingView.findViewById(R.id.Vector);
        checkBox57.setChecked(getConfig((String) checkBox57.getText()));
        checkBox57.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox57.getText()), checkBox57.isChecked());
            }
        });
        final CheckBox checkBox58 = (CheckBox) this.mFloatingView.findViewById(R.id.Uzi);
        checkBox58.setChecked(getConfig((String) checkBox58.getText()));
        checkBox58.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox58.getText()), checkBox58.isChecked());
            }
        });
        final CheckBox checkBox59 = (CheckBox) this.mFloatingView.findViewById(R.id.R1895);
        checkBox59.setChecked(getConfig((String) checkBox59.getText()));
        checkBox59.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox59.getText()), checkBox59.isChecked());
            }
        });
        final CheckBox checkBox60 = (CheckBox) this.mFloatingView.findViewById(R.id.Vz61);
        checkBox60.setChecked(getConfig((String) checkBox60.getText()));
        checkBox60.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox60.getText()), checkBox60.isChecked());
            }
        });
        final CheckBox checkBox61 = (CheckBox) this.mFloatingView.findViewById(R.id.P92);
        checkBox61.setChecked(getConfig((String) checkBox61.getText()));
        checkBox61.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox61.getText()), checkBox61.isChecked());
            }
        });
        final CheckBox checkBox62 = (CheckBox) this.mFloatingView.findViewById(R.id.P18C);
        checkBox62.setChecked(getConfig((String) checkBox62.getText()));
        checkBox62.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox62.getText()), checkBox62.isChecked());
            }
        });
        final CheckBox checkBox63 = (CheckBox) this.mFloatingView.findViewById(R.id.R45);
        checkBox63.setChecked(getConfig((String) checkBox63.getText()));
        checkBox63.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox63.getText()), checkBox63.isChecked());
            }
        });
        final CheckBox checkBox64 = (CheckBox) this.mFloatingView.findViewById(R.id.P1911);
        checkBox64.setChecked(getConfig((String) checkBox64.getText()));
        checkBox64.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox64.getText()), checkBox64.isChecked());
            }
        });
        final CheckBox checkBox65 = (CheckBox) this.mFloatingView.findViewById(R.id.DesertEagle);
        checkBox65.setChecked(getConfig((String) checkBox65.getText()));
        checkBox65.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox65.getText()), checkBox65.isChecked());
            }
        });
        final CheckBox checkBox66 = (CheckBox) this.mFloatingView.findViewById(R.id.Sickle);
        checkBox66.setChecked(getConfig((String) checkBox66.getText()));
        checkBox66.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox66.getText()), checkBox66.isChecked());
            }
        });
        final CheckBox checkBox67 = (CheckBox) this.mFloatingView.findViewById(R.id.Machete);
        checkBox67.setChecked(getConfig((String) checkBox67.getText()));
        checkBox67.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox67.getText()), checkBox67.isChecked());
            }
        });
        final CheckBox checkBox68 = (CheckBox) this.mFloatingView.findViewById(R.id.Pan);
        checkBox68.setChecked(getConfig((String) checkBox68.getText()));
        checkBox68.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox68.getText()), checkBox68.isChecked());
            }
        });
        final CheckBox checkBox69 = (CheckBox) this.mFloatingView.findViewById(R.id.Mk14);
        checkBox69.setChecked(getConfig((String) checkBox69.getText()));
        checkBox69.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox69.getText()), checkBox69.isChecked());
            }
        });
        final CheckBox checkBox70 = (CheckBox) this.mFloatingView.findViewById(R.id.sst);
        checkBox70.setChecked(getConfig((String) checkBox70.getText()));
        checkBox70.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox70.getText()), checkBox70.isChecked());
            }
        });
        final CheckBox checkBox71 = (CheckBox) this.mFloatingView.findViewById(R.id.ffACP);
        checkBox71.setChecked(getConfig((String) checkBox71.getText()));
        checkBox71.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox71.getText()), checkBox71.isChecked());
            }
        });
        final CheckBox checkBox72 = (CheckBox) this.mFloatingView.findViewById(R.id.ffs);
        checkBox72.setChecked(getConfig((String) checkBox72.getText()));
        checkBox72.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox72.getText()), checkBox72.isChecked());
            }
        });
        final CheckBox checkBox73 = (CheckBox) this.mFloatingView.findViewById(R.id.nmm);
        checkBox73.setChecked(getConfig((String) checkBox73.getText()));
        checkBox73.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox73.getText()), checkBox73.isChecked());
            }
        });
        final CheckBox checkBox74 = (CheckBox) this.mFloatingView.findViewById(R.id.tzzMagnum);
        checkBox74.setChecked(getConfig((String) checkBox74.getText()));
        checkBox74.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox74.getText()), checkBox74.isChecked());
            }
        });
        final CheckBox checkBox75 = (CheckBox) this.mFloatingView.findViewById(R.id.otGuage);
        checkBox75.setChecked(getConfig((String) checkBox75.getText()));
        checkBox75.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox75.getText()), checkBox75.isChecked());
            }
        });
        final CheckBox checkBox76 = (CheckBox) this.mFloatingView.findViewById(R.id.Choke);
        checkBox76.setChecked(getConfig((String) checkBox76.getText()));
        checkBox76.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox76.getText()), checkBox76.isChecked());
            }
        });
        final CheckBox checkBox77 = (CheckBox) this.mFloatingView.findViewById(R.id.SniperCompensator);
        checkBox77.setChecked(getConfig((String) checkBox77.getText()));
        checkBox77.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox77.getText()), checkBox77.isChecked());
            }
        });
        final CheckBox checkBox78 = (CheckBox) this.mFloatingView.findViewById(R.id.DP28);
        checkBox78.setChecked(getConfig((String) checkBox78.getText()));
        checkBox78.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox78.getText()), checkBox78.isChecked());
            }
        });
        final CheckBox checkBox79 = (CheckBox) this.mFloatingView.findViewById(R.id.M249);
        checkBox79.setChecked(getConfig((String) checkBox79.getText()));
        checkBox79.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox79.getText()), checkBox79.isChecked());
            }
        });
        final CheckBox checkBox80 = (CheckBox) this.mFloatingView.findViewById(R.id.Grenade);
        checkBox80.setChecked(getConfig((String) checkBox80.getText()));
        checkBox80.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox80.getText()), checkBox80.isChecked());
            }
        });
        final CheckBox checkBox81 = (CheckBox) this.mFloatingView.findViewById(R.id.Smoke);
        checkBox81.setChecked(getConfig((String) checkBox81.getText()));
        checkBox81.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox81.getText()), checkBox81.isChecked());
            }
        });
        final CheckBox checkBox82 = (CheckBox) this.mFloatingView.findViewById(R.id.Molotov);
        checkBox82.setChecked(getConfig((String) checkBox82.getText()));
        checkBox82.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox82.getText()), checkBox82.isChecked());
            }
        });
        final CheckBox checkBox83 = (CheckBox) this.mFloatingView.findViewById(R.id.Painkiller);
        checkBox83.setChecked(getConfig((String) checkBox83.getText()));
        checkBox83.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox83.getText()), checkBox83.isChecked());
            }
        });
        final CheckBox checkBox84 = (CheckBox) this.mFloatingView.findViewById(R.id.Adrenaline);
        checkBox84.setChecked(getConfig((String) checkBox84.getText()));
        checkBox84.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox84.getText()), checkBox84.isChecked());
            }
        });
        final CheckBox checkBox85 = (CheckBox) this.mFloatingView.findViewById(R.id.EnergyDrink);
        checkBox85.setChecked(getConfig((String) checkBox85.getText()));
        checkBox85.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox85.getText()), checkBox85.isChecked());
            }
        });
        final CheckBox checkBox86 = (CheckBox) this.mFloatingView.findViewById(R.id.FirstAidKit);
        checkBox86.setChecked(getConfig((String) checkBox86.getText()));
        checkBox86.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox86.getText()), checkBox86.isChecked());
            }
        });
        final CheckBox checkBox87 = (CheckBox) this.mFloatingView.findViewById(R.id.Bandage);
        checkBox87.setChecked(getConfig((String) checkBox87.getText()));
        checkBox87.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox87.getText()), checkBox87.isChecked());
            }
        });
        final CheckBox checkBox88 = (CheckBox) this.mFloatingView.findViewById(R.id.Medkit);
        checkBox88.setChecked(getConfig((String) checkBox88.getText()));
        checkBox88.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox88.getText()), checkBox88.isChecked());
            }
        });
        final CheckBox checkBox89 = (CheckBox) this.mFloatingView.findViewById(R.id.FlareGun);
        checkBox89.setChecked(getConfig((String) checkBox89.getText()));
        checkBox89.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox89.getText()), checkBox89.isChecked());
            }
        });
        final CheckBox checkBox90 = (CheckBox) this.mFloatingView.findViewById(R.id.GullieSuit);
        checkBox90.setChecked(getConfig((String) checkBox90.getText()));
        checkBox90.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox90.getText()), checkBox90.isChecked());
            }
        });
        final CheckBox checkBox91 = (CheckBox) this.mFloatingView.findViewById(R.id.UMP);
        checkBox91.setChecked(getConfig((String) checkBox91.getText()));
        checkBox91.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox91.getText()), checkBox91.isChecked());
            }
        });
        final CheckBox checkBox92 = (CheckBox) this.mFloatingView.findViewById(R.id.Bizon);
        checkBox92.setChecked(getConfig((String) checkBox92.getText()));
        checkBox92.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox92.getText()), checkBox92.isChecked());
            }
        });
        final CheckBox checkBox93 = (CheckBox) this.mFloatingView.findViewById(R.id.CompensatorSMG);
        checkBox93.setChecked(getConfig((String) checkBox93.getText()));
        checkBox93.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox93.getText()), checkBox93.isChecked());
            }
        });
        final CheckBox checkBox94 = (CheckBox) this.mFloatingView.findViewById(R.id.FlashHiderSMG);
        checkBox94.setChecked(getConfig((String) checkBox94.getText()));
        checkBox94.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox94.getText()), checkBox94.isChecked());
            }
        });
        final CheckBox checkBox95 = (CheckBox) this.mFloatingView.findViewById(R.id.FlashHiderAr);
        checkBox95.setChecked(getConfig((String) checkBox95.getText()));
        checkBox95.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox95.getText()), checkBox95.isChecked());
            }
        });
        final CheckBox checkBox96 = (CheckBox) this.mFloatingView.findViewById(R.id.ArCompensator);
        checkBox96.setChecked(getConfig((String) checkBox96.getText()));
        checkBox96.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox96.getText()), checkBox96.isChecked());
            }
        });
        final CheckBox checkBox97 = (CheckBox) this.mFloatingView.findViewById(R.id.TacticalStock);
        checkBox97.setChecked(getConfig((String) checkBox97.getText()));
        checkBox97.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox97.getText()), checkBox97.isChecked());
            }
        });
        final CheckBox checkBox98 = (CheckBox) this.mFloatingView.findViewById(R.id.Duckbill);
        checkBox98.setChecked(getConfig((String) checkBox98.getText()));
        checkBox98.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox98.getText()), checkBox98.isChecked());
            }
        });
        final CheckBox checkBox99 = (CheckBox) this.mFloatingView.findViewById(R.id.FlashHiderSniper);
        checkBox99.setChecked(getConfig((String) checkBox99.getText()));
        checkBox99.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox99.getText()), checkBox99.isChecked());
            }
        });
        final CheckBox checkBox100 = (CheckBox) this.mFloatingView.findViewById(R.id.SuppressorSMG);
        checkBox100.setChecked(getConfig((String) checkBox100.getText()));
        checkBox100.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox100.getText()), checkBox100.isChecked());
            }
        });
        final CheckBox checkBox101 = (CheckBox) this.mFloatingView.findViewById(R.id.HalfGrip);
        checkBox101.setChecked(getConfig((String) checkBox101.getText()));
        checkBox101.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox101.getText()), checkBox101.isChecked());
            }
        });
        final CheckBox checkBox102 = (CheckBox) this.mFloatingView.findViewById(R.id.StockMicroUZI);
        checkBox102.setChecked(getConfig((String) checkBox102.getText()));
        checkBox102.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox102.getText()), checkBox102.isChecked());
            }
        });
        final CheckBox checkBox103 = (CheckBox) this.mFloatingView.findViewById(R.id.SuppressorSniper);
        checkBox103.setChecked(getConfig((String) checkBox103.getText()));
        checkBox103.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox103.getText()), checkBox103.isChecked());
            }
        });
        final CheckBox checkBox104 = (CheckBox) this.mFloatingView.findViewById(R.id.SuppressorAr);
        checkBox104.setChecked(getConfig((String) checkBox104.getText()));
        checkBox104.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox104.getText()), checkBox104.isChecked());
            }
        });
        final CheckBox checkBox105 = (CheckBox) this.mFloatingView.findViewById(R.id.ExQdSniper);
        checkBox105.setChecked(getConfig((String) checkBox105.getText()));
        checkBox105.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox105.getText()), checkBox105.isChecked());
            }
        });
        final CheckBox checkBox106 = (CheckBox) this.mFloatingView.findViewById(R.id.QdSMG);
        checkBox106.setChecked(getConfig((String) checkBox106.getText()));
        checkBox106.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox106.getText()), checkBox106.isChecked());
            }
        });
        final CheckBox checkBox107 = (CheckBox) this.mFloatingView.findViewById(R.id.ExSMG);
        checkBox107.setChecked(getConfig((String) checkBox107.getText()));
        checkBox107.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox107.getText()), checkBox107.isChecked());
            }
        });
        final CheckBox checkBox108 = (CheckBox) this.mFloatingView.findViewById(R.id.QdSniper);
        checkBox108.setChecked(getConfig((String) checkBox108.getText()));
        checkBox108.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox108.getText()), checkBox108.isChecked());
            }
        });
        final CheckBox checkBox109 = (CheckBox) this.mFloatingView.findViewById(R.id.ExSniper);
        checkBox109.setChecked(getConfig((String) checkBox109.getText()));
        checkBox109.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox109.getText()), checkBox109.isChecked());
            }
        });
        final CheckBox checkBox110 = (CheckBox) this.mFloatingView.findViewById(R.id.ExAr);
        checkBox110.setChecked(getConfig((String) checkBox110.getText()));
        checkBox110.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox110.getText()), checkBox110.isChecked());
            }
        });
        final CheckBox checkBox111 = (CheckBox) this.mFloatingView.findViewById(R.id.ExQdAr);
        checkBox111.setChecked(getConfig((String) checkBox111.getText()));
        checkBox111.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox111.getText()), checkBox111.isChecked());
            }
        });
        final CheckBox checkBox112 = (CheckBox) this.mFloatingView.findViewById(R.id.QdAr);
        checkBox112.setChecked(getConfig((String) checkBox112.getText()));
        checkBox112.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox112.getText()), checkBox112.isChecked());
            }
        });
        final CheckBox checkBox113 = (CheckBox) this.mFloatingView.findViewById(R.id.ExQdSMG);
        checkBox113.setChecked(getConfig((String) checkBox113.getText()));
        checkBox113.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox113.getText()), checkBox113.isChecked());
            }
        });
        final CheckBox checkBox114 = (CheckBox) this.mFloatingView.findViewById(R.id.QuiverCrossBow);
        checkBox114.setChecked(getConfig((String) checkBox114.getText()));
        checkBox114.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox114.getText()), checkBox114.isChecked());
            }
        });
        final CheckBox checkBox115 = (CheckBox) this.mFloatingView.findViewById(R.id.BulletLoop);
        checkBox115.setChecked(getConfig((String) checkBox115.getText()));
        checkBox115.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox115.getText()), checkBox115.isChecked());
            }
        });
        final CheckBox checkBox116 = (CheckBox) this.mFloatingView.findViewById(R.id.ThumbGrip);
        checkBox116.setChecked(getConfig((String) checkBox116.getText()));
        checkBox116.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox116.getText()), checkBox116.isChecked());
            }
        });
        final CheckBox checkBox117 = (CheckBox) this.mFloatingView.findViewById(R.id.LaserSight);
        checkBox117.setChecked(getConfig((String) checkBox117.getText()));
        checkBox117.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox117.getText()), checkBox117.isChecked());
            }
        });
        final CheckBox checkBox118 = (CheckBox) this.mFloatingView.findViewById(R.id.AngledGrip);
        checkBox118.setChecked(getConfig((String) checkBox118.getText()));
        checkBox118.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox118.getText()), checkBox118.isChecked());
            }
        });
        final CheckBox checkBox119 = (CheckBox) this.mFloatingView.findViewById(R.id.LightGrip);
        checkBox119.setChecked(getConfig((String) checkBox119.getText()));
        checkBox119.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox119.getText()), checkBox119.isChecked());
            }
        });
        final CheckBox checkBox120 = (CheckBox) this.mFloatingView.findViewById(R.id.VerticalGrip);
        checkBox120.setChecked(getConfig((String) checkBox120.getText()));
        checkBox120.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox120.getText()), checkBox120.isChecked());
            }
        });
        final CheckBox checkBox121 = (CheckBox) this.mFloatingView.findViewById(R.id.GasCan);
        checkBox121.setChecked(getConfig((String) checkBox121.getText()));
        checkBox121.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox121.getText()), checkBox121.isChecked());
            }
        });
        final CheckBox checkBox122 = (CheckBox) this.mFloatingView.findViewById(R.id.Arrow);
        checkBox122.setChecked(getConfig((String) checkBox122.getText()));
        checkBox122.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox122.getText()), checkBox122.isChecked());
            }
        });
        final CheckBox checkBox123 = (CheckBox) this.mFloatingView.findViewById(R.id.CrossBow);
        checkBox123.setChecked(getConfig((String) checkBox123.getText()));
        checkBox123.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox123.getText()), checkBox123.isChecked());
            }
        });
        final CheckBox checkBox124 = (CheckBox) this.mFloatingView.findViewById(R.id.Baglvl1);
        checkBox124.setChecked(getConfig((String) checkBox124.getText()));
        checkBox124.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox124.getText()), checkBox124.isChecked());
            }
        });
        final CheckBox checkBox125 = (CheckBox) this.mFloatingView.findViewById(R.id.Baglvl2);
        checkBox125.setChecked(getConfig((String) checkBox125.getText()));
        checkBox125.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox125.getText()), checkBox125.isChecked());
            }
        });
        final CheckBox checkBox126 = (CheckBox) this.mFloatingView.findViewById(R.id.Baglvl3);
        checkBox126.setChecked(getConfig((String) checkBox126.getText()));
        checkBox126.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox126.getText()), checkBox126.isChecked());
            }
        });
        final CheckBox checkBox127 = (CheckBox) this.mFloatingView.findViewById(R.id.Helmetlvl1);
        checkBox127.setChecked(getConfig((String) checkBox127.getText()));
        checkBox127.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox127.getText()), checkBox127.isChecked());
            }
        });
        final CheckBox checkBox128 = (CheckBox) this.mFloatingView.findViewById(R.id.Helmetlvl2);
        checkBox128.setChecked(getConfig((String) checkBox128.getText()));
        checkBox128.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox128.getText()), checkBox128.isChecked());
            }
        });
        final CheckBox checkBox129 = (CheckBox) this.mFloatingView.findViewById(R.id.Helmetlvl3);
        checkBox129.setChecked(getConfig((String) checkBox129.getText()));
        checkBox129.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox129.getText()), checkBox129.isChecked());
            }
        });
        final CheckBox checkBox130 = (CheckBox) this.mFloatingView.findViewById(R.id.Vestlvl1);
        checkBox130.setChecked(getConfig((String) checkBox130.getText()));
        checkBox130.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox130.getText()), checkBox130.isChecked());
            }
        });
        final CheckBox checkBox131 = (CheckBox) this.mFloatingView.findViewById(R.id.Vestlvl2);
        checkBox131.setChecked(getConfig((String) checkBox131.getText()));
        checkBox131.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox131.getText()), checkBox131.isChecked());
            }
        });
        final CheckBox checkBox132 = (CheckBox) this.mFloatingView.findViewById(R.id.Vestlvl3);
        checkBox132.setChecked(getConfig((String) checkBox132.getText()));
        checkBox132.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox132.getText()), checkBox132.isChecked());
            }
        });
        final CheckBox checkBox133 = (CheckBox) this.mFloatingView.findViewById(R.id.Stung);
        checkBox133.setChecked(getConfig((String) checkBox133.getText()));
        checkBox133.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox133.getText()), checkBox133.isChecked());
            }
        });
        final CheckBox checkBox134 = (CheckBox) this.mFloatingView.findViewById(R.id.Crowbar);
        checkBox134.setChecked(getConfig((String) checkBox134.getText()));
        checkBox134.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(checkBox134.getText()), checkBox134.isChecked());
            }
        });
        final SeekBar seekBar = (SeekBar) this.mFloatingView.findViewById(R.id.fps);
        seekBar.setProgress(getFps());
        a.ChangeFps(getFps());
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                int progress = seekBar.getProgress();
                b.this.setFps(progress);
                a.ChangeFps(progress);
            }
        });
        final SeekBar seekBar2 = (SeekBar) this.mFloatingView.findViewById(R.id.range);
        seekBar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                b.this.Range(seekBar2.getProgress());
            }
        });
        final RadioGroup radioGroup = (RadioGroup) this.mFloatingView.findViewById(R.id.aimby);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                b.this.AimBy(Integer.parseInt(((RadioButton) b.this.mFloatingView.findViewById(radioGroup.getCheckedRadioButtonId())).getTag().toString()));
            }
        });
        final RadioGroup radioGroup2 = (RadioGroup) this.mFloatingView.findViewById(R.id.aimwhen);
        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                b.this.AimWhen(Integer.parseInt(((RadioButton) b.this.mFloatingView.findViewById(radioGroup2.getCheckedRadioButtonId())).getTag().toString()));
            }
        });
        final RadioGroup radioGroup3 = (RadioGroup) this.mFloatingView.findViewById(R.id.aimbotmode);
        radioGroup3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                b.this.Target(Integer.parseInt(((RadioButton) b.this.mFloatingView.findViewById(radioGroup3.getCheckedRadioButtonId())).getTag().toString()));
            }
        });
        final Switch switchR11 = (Switch) this.mFloatingView.findViewById(R.id.aimbot);
        SettingValue(11, false);
        switchR11.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.setValue(String.valueOf(switchR11.getText()), switchR11.isChecked());
                if (switchR11.isChecked()) {
                    b.this.createOver2();
                } else if (b.this.mFloatingView2 != null) {
                    b.this.mWindowManager2.removeView(b.this.mFloatingView2);
                }
            }
        });
        Switch switchR12 = (Switch) this.mFloatingView.findViewById(R.id.aimknocked);
        switchR12.setChecked(getConfig((String) switchR12.getText()));
        SettingValue(13, getConfig((String) switchR12.getText()));
        switchR12.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            private /* synthetic */ Switch f$1;


            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                b.this.lambda$Init$0$b(this.f$1, compoundButton, z);
            }
        });
    }

    public /* synthetic */ void lambda$Init$0$b(Switch switchR, CompoundButton compoundButton, boolean z) {
        setValue(String.valueOf(switchR.getText()), switchR.isChecked());
        SettingValue(13, switchR.isChecked());
    }
}
