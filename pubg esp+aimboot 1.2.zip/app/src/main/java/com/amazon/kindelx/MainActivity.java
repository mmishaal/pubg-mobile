package com.amazon.kindelx;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.AuToCheaTs.Free.R;
import com.scottyab.rootbeer.Const;
import com.scottyab.rootbeer.RootBeer;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    static boolean bitMod = false;
    static int gameType = 1;
    static boolean is32 = false;
    static boolean is64 = false;
    static boolean isIND = false;
    static boolean isInt = true;
    static boolean isNoroot = false;
    static boolean isRoot = false;
    static boolean rootMod = false;
    public static String socket;
    static boolean verMod = true;
    public String MemHack;
    int bit = 1;
    LinearLayout brand;
    TextView clc;
    Context ctx;
    public String daemonPath;
    public String daemonPath64;
    public String daemonPathIND;
    String gameName = "com.tencent.ig";
    LinearLayout gll;
    TextView glv;
    String indMEM;
    public boolean isDaemon = false;
    private boolean isDisplay = false;
    private boolean isMenuDis = false;
    public Button join;
    LinearLayout krl;
    TextView krv;
    LinearLayout logout;
    public Button mbutton1;
    public Button mbutton2;
    public Button mbutton3;
    public Button mbutton4;
    public Button mbutton5;
    public Button mbutton6;
    View menu;
    TextView msg;

    /* renamed from: mx */
    int f69mx;

    /* renamed from: my */
    int f70my;
    public boolean onESP = false;
    Process process;
    private RadioButton radiobutton1;
    private RadioButton radiobutton2;
    private RadioButton radiobutton3;
    private RadioButton radiobutton4;
    private RadioButton radiobutton5;
    private RadioButton radiobutton6;
    private RadioGroup radiogroup1;
    private RadioGroup radiogroup2;
    private RadioGroup radiogroup3;
    ImageView root_img;
    Button sell;
    Button start;
    Button stop;
    LinearLayout telegram;
    LinearLayout translate;
    LinearLayout twl;
    TextView twv;
    LinearLayout vtl;
    TextView vtv;

    static {
        System.loadLibrary("native-lib");
    }

    /* access modifiers changed from: protected */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.main);
        CheckFloatViewPermission();
        this.ctx = this;
        if (!isConfigExist()) {
            Init();
        }
        this.start = (Button) findViewById(R.id.start);
        this.stop = (Button) findViewById(R.id.stop);
        this.root_img = (ImageView) findViewById(R.id.root_img);
        this.brand = (LinearLayout) findViewById(R.id.brand_ll);
        this.telegram = (LinearLayout) findViewById(R.id.telegram_ll);
        this.translate = (LinearLayout) findViewById(R.id.translate_ll);
        this.logout = (LinearLayout) findViewById(R.id.logout_ll);
        this.sell = (Button) findViewById(R.id.sell);
        this.join = (Button) findViewById(R.id.join);
        //this.brand.setOnClickListener(this);
//        this.telegram.setOnClickListener(this);
       // this.translate.setOnClickListener(this);
//        this.logout.setOnClickListener(this);
       // this.sell.setOnClickListener(this);
        this.start.setOnClickListener(this);
        this.stop.setOnClickListener(this);
        this.gll = (LinearLayout) findViewById(R.id.sglih);
        this.krl = (LinearLayout) findViewById(R.id.skrih);
        this.twl = (LinearLayout) findViewById(R.id.stwih);
        this.vtl = (LinearLayout) findViewById(R.id.svnih);
        this.msg = (TextView) findViewById(R.id.card_text);
        this.glv = (TextView) findViewById(R.id.sgli);
        this.krv = (TextView) findViewById(R.id.skri);
        this.twv = (TextView) findViewById(R.id.stwi);
        this.vtv = (TextView) findViewById(R.id.svni);
        this.glv.setOnClickListener(this);
        this.krv.setOnClickListener(this);
        this.twv.setOnClickListener(this);
        this.vtv.setOnClickListener(this);
      //  this.msg.setOnClickListener(this);
//        this.join.setOnClickListener(this);
        this.radiogroup1 = (RadioGroup) findViewById(R.id.radioInd);
        this.radiogroup2 = (RadioGroup) findViewById(R.id.radioMod);
        this.radiogroup3 = (RadioGroup) findViewById(R.id.radioBit);
        this.radiobutton1 = (RadioButton) findViewById(R.id.radiobutton1);
        this.radiobutton2 = (RadioButton) findViewById(R.id.radiobutton2);
        this.radiobutton3 = (RadioButton) findViewById(R.id.radiobutton3);
        this.radiobutton4 = (RadioButton) findViewById(R.id.radiobutton4);
        this.radiobutton5 = (RadioButton) findViewById(R.id.radiobutton5);
        this.radiobutton6 = (RadioButton) findViewById(R.id.radiobutton6);
        try {
            this.process = Runtime.getRuntime().exec("su -c");
        } catch (IOException e) {
            e.printStackTrace();
            this.process = null;
        }
        this.radiogroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.radiobutton1 /*2131296732*/:
                        MainActivity.isIND = true;
                        MainActivity.isInt = false;
                        MainActivity.this.indMEM = "IND";
                        MainActivity.verMod = true;
                        return;
                    case R.id.radiobutton2 /*2131296733*/:
                        MainActivity.isInt = true;
                        MainActivity.isIND = false;
                        MainActivity.this.indMEM = "INTER";
                        MainActivity.verMod = true;
                        return;
                    default:
                }
            }
        });
        this.radiogroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.radiobutton3 /*2131296734*/:
                        MainActivity.isRoot = true;
                        MainActivity.this.ExecuteElf("su -c");
                        MainActivity.isNoroot = false;
                        MainActivity.rootMod = true;
                        return;
                    case R.id.radiobutton4 /*2131296735*/:
                        MainActivity.isNoroot = true;
                        MainActivity.isRoot = false;
                        MainActivity.rootMod = true;
                        return;
                    default:
                }
            }
        });
        this.radiogroup3.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.radiobutton5 /*2131296736*/:
                        MainActivity.is32 = true;
                        MainActivity.is64 = false;
                        MainActivity.bitMod = true;
                        return;
                    case R.id.radiobutton6 /*2131296737*/:
                        MainActivity.is64 = true;
                        MainActivity.is32 = false;
                        MainActivity.bitMod = true;
                        return;
                    default:
                }
            }
        });
        ExecuteElf("su -c");
        loadAssets();
        loadAssets64();
        loadAssetsIND();
        socket = this.daemonPath;
        if (new RootBeer(this).isRooted()) {
            this.root_img.setBackgroundResource(R.drawable.ic_root_on);
        } else {
            this.root_img.setBackgroundResource(R.drawable.ic_root_off);
        }
        int i = Calendar.getInstance().get(5);
        String string = getSharedPreferences(Constants.USER_AUTH, 0).getString("day", (String) null);
        PrintStream printStream = System.out;
        printStream.println("cool day " + i);
        if (string == null) {
            SharedPreferences.Editor edit = getSharedPreferences(Constants.USER_AUTH, 0).edit();
            edit.putString("day", String.valueOf(i));
            edit.apply();
        } else if (!string.equals(String.valueOf(i))) {
            SharedPreferences.Editor edit2 = getSharedPreferences(Constants.USER_AUTH, 0).edit();
            edit2.putString("day", String.valueOf(i));
            edit2.apply();
        }
    }



    @SuppressLint("WrongConstant")
    public void onClick(View view) {
        boolean z;
        switch (view.getId()) {
            case R.id.sgli /*2131296778*/:
                this.glv.setBackgroundResource(R.drawable.bg_border_green);
                this.krv.setBackgroundResource(R.drawable.bg_borderred);
                this.vtv.setBackgroundResource(R.drawable.bg_borderred);
                this.twv.setBackgroundResource(R.drawable.bg_borderred);
                this.gameName = "com.tencent.ig";
                gameType = 1;
                return;
            case R.id.skri /*2131296790*/:
                this.krv.setBackgroundResource(R.drawable.bg_border_green);
                this.glv.setBackgroundResource(R.drawable.bg_borderred);
                this.vtv.setBackgroundResource(R.drawable.bg_borderred);
                this.twv.setBackgroundResource(R.drawable.bg_borderred);
                this.gameName = "com.pubg.krmobile";
                gameType = 2;
                return;
            case R.id.start /*2131296812*/:
                boolean z2 = this.isDisplay;
                if (!z2 && !(z = this.isMenuDis)) {
                    if (!rootMod || !verMod || !bitMod) {
                        Toast.makeText(this, "Please Select Settings First !!", 1).show();
                        return;
                    } else if (z2 || z) {
                        Toast.makeText(this, "Already Started !!", 1).show();
                        return;
                    } else {
                        if (isNoroot) {
                            if (is32) {
                                if (isIND) {
                                    socket = this.daemonPathIND;
                                } else {
                                    socket = this.daemonPath;
                                }
                            } else if (is64) {
                                if (isIND) {
                                    socket = this.daemonPathIND;
                                } else {
                                    socket = this.daemonPath64;
                                }
                            }
                        }
                        if (isRoot) {
                            if (is32) {
                                if (isIND) {
                                    socket = "su -c " + this.daemonPathIND;
                                } else {
                                    socket = "su -c " + this.daemonPath;
                                }
                            } else if (is64) {
                                if (isIND) {
                                    socket = "su -c " + this.daemonPathIND;
                                } else {
                                    socket = "su -c " + this.daemonPath64;
                                }
                            }
                        }
                        try {
                            DataOutputStream dataOutputStream = new DataOutputStream(Runtime.getRuntime().exec(Const.BINARY_SU).getOutputStream());
                            dataOutputStream.writeBytes(" am start -n " + this.gameName + "/com.epicgames.ue4.SplashActivity \n");
                            dataOutputStream.flush();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        this.start.setVisibility(8);
                        this.stop.setVisibility(0);
                        startPatcher();
                        startService(new Intent(this, e.class));
                        this.isDisplay = true;
                        this.isDaemon = true;
                        return;
                    }
                } else {
                    return;
                }
            case R.id.stop /*2131296817*/:
                this.start.setVisibility(0);
                this.stop.setVisibility(8);
                if (this.isDisplay) {
                    this.isDisplay = false;
                    this.isMenuDis = false;
                    this.isDaemon = false;
                    stopService(new Intent(this, b.class));
                    stopService(new Intent(this, e.class));
                    return;
                }
                return;
            case R.id.stwi /*2131296819*/:
                this.twv.setBackgroundResource(R.drawable.bg_border_green);
                this.krv.setBackgroundResource(R.drawable.bg_borderred);
                this.vtv.setBackgroundResource(R.drawable.bg_borderred);
                this.glv.setBackgroundResource(R.drawable.bg_borderred);
                this.gameName = "com.rekoo.pubgm";
                gameType = 4;
                return;
            case R.id.svni /*2131296823*/:
                this.vtv.setBackgroundResource(R.drawable.bg_border_green);
                this.krv.setBackgroundResource(R.drawable.bg_borderred);
                this.glv.setBackgroundResource(R.drawable.bg_borderred);
                this.twv.setBackgroundResource(R.drawable.bg_borderred);
                this.gameName = "com.vng.pubgmobile";
                gameType = 3;
                return;
            default:
        }
    }

    @SuppressLint("WrongConstant")
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void CheckFloatViewPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Floating Permission ", 1).show();
            startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 0);
        }
    }

    private boolean isServiceRunning() {
        @SuppressLint("WrongConstant") ActivityManager activityManager = (ActivityManager) getSystemService("activity");
        if (activityManager == null) {
            return false;
        }
        for (ActivityManager.RunningServiceInfo runningServiceInfo : activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if (b.class.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public void startPatcher() {
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            startFloater();
            return;
        }
        startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), 123);
    }

    @SuppressLint("WrongConstant")
    private void startFloater() {
        if (!isServiceRunning()) {
            startService(new Intent(this, b.class));
        } else {
            Toast.makeText(this, "Service Already Running!", 0).show();
        }
    }

    /* access modifiers changed from: private */
    public void ExecuteElf(String str) {
        try {
            Runtime.getRuntime().exec(str, (String[]) null, (File) null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Shell(String str) {
        DataOutputStream dataOutputStream = null;
        try {
            this.process = Runtime.getRuntime().exec(str);
        } catch (IOException e) {
            e.printStackTrace();
            this.process = null;
        }
        if (this.process != null) {
            dataOutputStream = new DataOutputStream(this.process.getOutputStream());
        }
        try {
            dataOutputStream.flush();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        try {
            this.process.waitFor();
        } catch (InterruptedException e3) {
            e3.printStackTrace();
        }
    }

    public void startDaemon() {
        new Thread() {
            public void run() {
                MainActivity.this.Shell(MainActivity.socket);
            }
        }.start();
    }

    public void loadAssets() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(getFilesDir().toString() + "/sock");
            byte[] bArr = new byte[1024];
            InputStream open = getAssets().open("sock");
            while (true) {
                int read = open.read(bArr);
                if (read <= 0) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            open.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (IOException unused) {
        }
        this.daemonPath = getFilesDir().toString() + "/sock";
        try {
            Runtime runtime = Runtime.getRuntime();
            runtime.exec("chmod 777 " + this.daemonPath);
        } catch (IOException unused2) {
        }
    }

    public void loadAssets64() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(getFilesDir().toString() + "/sock64");
            byte[] bArr = new byte[1024];
            InputStream open = getAssets().open("sock64");
            while (true) {
                int read = open.read(bArr);
                if (read <= 0) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            open.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (IOException unused) {
        }
        this.daemonPath64 = getFilesDir().toString() + "/sock64";
        try {
            Runtime runtime = Runtime.getRuntime();
            runtime.exec("chmod 777 " + this.daemonPath64);
        } catch (IOException unused2) {
        }
    }

    public void loadAssetsIND() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(getFilesDir().toString() + "/sockind");
            byte[] bArr = new byte[1024];
            InputStream open = getAssets().open("sockind");
            while (true) {
                int read = open.read(bArr);
                if (read <= 0) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            open.close();
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (IOException unused) {
        }
        this.daemonPathIND = getFilesDir().toString() + "/sockind";
        try {
            Runtime runtime = Runtime.getRuntime();
            runtime.exec("chmod 777 " + this.daemonPathIND);
        } catch (IOException unused2) {
        }
    }

    /* access modifiers changed from: package-private */
    public void Init() {
        SharedPreferences.Editor edit = getApplicationContext().getSharedPreferences("espValue", 0).edit();
        edit.putInt("fps", 30);
        edit.putBoolean("Box", true);
        edit.putBoolean("Line", true);
        edit.putBoolean("Distance", false);
        edit.putBoolean("Health", false);
        edit.putBoolean("Name", false);
        edit.putBoolean("Head Position", false);
        edit.putBoolean("Back Mark", false);
        edit.putBoolean("Skelton", false);
        edit.putBoolean("Grenade Warning", false);
        edit.putBoolean("Enemy Weapon", false);
        edit.apply();
    }

    /* access modifiers changed from: package-private */
    public boolean isConfigExist() {
        return getApplicationContext().getSharedPreferences("espValue", 0).contains("fps");
    }
}
